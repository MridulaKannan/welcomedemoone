package com.example.OfficeData.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.OfficeData.dao.RegistrationDb;
import com.example.OfficeData.dao.RegistrationLogin;
import com.example.OfficeData.service.RegistrationService;


@RestController
public class RegistrationController {
	@Autowired
	RegistrationService regService;
	
	//login page
	@GetMapping(value="fetchRegistrationLogin")
	public List<RegistrationLogin> getRegistrationLogin()
	{
		List<RegistrationLogin> regList=regService.getRegistrationLogin();
		return regList;
	}
	
	@PostMapping(value="/checkLogin")
		public String validateRegistrationLogin(@RequestBody RegistrationLogin r)
		{
		System.out.println(r.getUsername());
			return regService.validateRegistrationLogin(r.getUsername(),r.getPassword());
		}
	
	@PostMapping(value="/addRegistrationLogin")
	public RegistrationLogin saveRegistrationLogin(@RequestBody RegistrationLogin r)
	{
	return regService.saveRegistrationLogin(r);
	
	}
	
	//registrationDb
	@GetMapping(value="fetchRegistrationDb")
	public List<RegistrationDb> getRegistrationDb()
	{
		List<RegistrationDb> regDb=regService.getRegistrationDb();
		return regDb;
	}
	@PostMapping(value="/saveRegistrationDb")
	public  RegistrationDb saveRegistrationDb(@RequestBody RegistrationDb d)
	{
		 return regService.saveRegistrationDb(d);
	}
	//sorting
	@GetMapping(value="/sortRegistrationDb/{field}")
	public List<RegistrationDb> sortRegistrationDb(@PathVariable String field)
	{
		return regService.sortRegistrationDb(field);
	}
	
	//Paging interface
	@GetMapping("/pagingRegistrationDb/{offset}/{pageSize}")
	public List<RegistrationDb> pagingRegistrationDb(@PathVariable int offset,@PathVariable int pageSize)
	{
		return regService.pagingRegistrationDb(offset,pageSize);
	}
	
	@GetMapping("/pagingsRegistrationDb/{offset}/{pageSize}")
	public Page<RegistrationDb> pagingsRegistrationDb(@PathVariable int offset,@PathVariable int pageSize)
	{
		return regService.pagingsRegistrationDb(offset,pageSize);
	}
	//paging and sorting
	
	@GetMapping("/pagingAndSortingRegistrationDb/{offset}/{pageSize}/{field}")
	public List<RegistrationDb> pagingAndSortingRegistrationDb(@PathVariable int offset,@PathVariable int pageSize,@PathVariable String field)
	{
		return regService.pagingAndSortingRegistrationDb(offset,pageSize,field);
	}
	
	
}
