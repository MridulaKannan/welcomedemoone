package com.example.OfficeData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
